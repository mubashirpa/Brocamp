package com.sample.simplelogin

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sample.simplelogin.ui.theme.SImpleLoginTheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SImpleLoginTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    val context = LocalContext.current
                    val coroutineScope = rememberCoroutineScope()
                    val navController = rememberNavController()
                    val isLoggedIn by isLoggedIn(context).collectAsStateWithLifecycle(
                        initialValue = null,
                    )

                    if (isLoggedIn != null) {
                        NavHost(
                            navController = navController,
                            startDestination = if (isLoggedIn == true) Home else Login,
                            modifier =
                                Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding),
                        ) {
                            composable<Login> {
                                LoginScreen(
                                    onLogin = {
                                        coroutineScope.launch {
                                            loginUser(context) {
                                                navController.navigate(Home) {
                                                    popUpTo(Login) { inclusive = true }
                                                }
                                            }
                                        }
                                    },
                                )
                            }
                            composable<Home> {
                                HomeScreen(
                                    onLogOut = {
                                        coroutineScope.launch {
                                            logoutUser(context) {
                                                navController.navigate(Login) {
                                                    popUpTo(Home) { inclusive = true }
                                                }
                                            }
                                        }
                                    },
                                )
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center,
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                }
            }
        }
    }
}

@Serializable
data object Login

@Serializable
data object Home

private fun isLoggedIn(context: Context): Flow<Boolean?> =
    context.dataStore.data
        .map { settings ->
            settings[booleanPreferencesKey("login")]
        }

suspend fun loginUser(
    context: Context,
    onLoginSuccess: () -> Unit,
) {
    context.dataStore.edit { settings ->
        settings[booleanPreferencesKey("login")] = true
    }
    onLoginSuccess()
}

suspend fun logoutUser(
    context: Context,
    onLogoutSuccess: () -> Unit,
) {
    context.dataStore.edit { settings ->
        settings[booleanPreferencesKey("login")] = false
    }
    onLogoutSuccess()
}
