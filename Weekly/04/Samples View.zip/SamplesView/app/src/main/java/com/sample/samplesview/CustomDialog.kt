package com.sample.samplesview

import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment

class CustomDialog : DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        activity?.let {
            val builder = AlertDialog.Builder(it)
            val inflater = it.layoutInflater

            builder
                .setView(inflater.inflate(R.layout.dialog_signin, null))
                .setPositiveButton("Sign in") { dialog, id -> }
                .setNegativeButton("Cancel") { dialog, id -> }
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
}
