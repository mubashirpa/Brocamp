package com.sample.samplesview

import androidx.fragment.app.Fragment

class FragmentOne : Fragment(R.layout.fragment_one)
