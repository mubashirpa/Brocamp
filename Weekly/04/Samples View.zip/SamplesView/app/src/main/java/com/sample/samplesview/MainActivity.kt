package com.sample.samplesview

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar
import com.sample.samplesview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        binding.dialogButton.setOnClickListener {
            showDialog(this)
        }

        binding.customDialogButton.setOnClickListener {
            CustomDialog().show(supportFragmentManager, "CUSTOM_DIALOG")
        }

        binding.messageButton.setOnClickListener {
            showToast(this, "This is a message")
        }

        binding.snackbarButton.setOnClickListener {
            showSnackbar(binding.root, "This is a snackbar") {
                showToast(this, "Snackbar closed")
            }
        }

        binding.menuButton.setOnClickListener {
            showPopupMenu(this, binding.menuButton)
        }

        binding.fragmentActivityButton.setOnClickListener {
            Intent(this, FragmentActivity::class.java).also {
                startActivity(it)
            }
        }

        binding.dataActivityButton.setOnClickListener {
            Intent(this, DataActivity::class.java).also {
                startActivity(it)
            }
        }
    }
}

private fun showDialog(context: Context) {
    AlertDialog
        .Builder(context)
        .setTitle("Sample title")
        .setMessage("Sample message")
        .setPositiveButton("OK") { dialog, which ->
            showToast(context, "OK")
        }.setNegativeButton("Close") { dialog, which ->
            showToast(context, "Close")
        }.show()
}

private fun showToast(
    context: Context,
    message: String,
) {
    Toast.makeText(context, message, Toast.LENGTH_LONG).show()
}

private fun showSnackbar(
    view: View,
    message: String,
    onClick: () -> Unit,
) {
    val snackbar =
        Snackbar.make(view, message, Snackbar.LENGTH_LONG).setAction("OK") { onClick() }
    snackbar.show()
}

private fun showPopupMenu(
    context: Context,
    view: View,
) {
    val popupMenu = PopupMenu(context, view)
    popupMenu.menuInflater.inflate(R.menu.popup_menu, popupMenu.menu)

    popupMenu.setOnMenuItemClickListener {
        when (it.itemId) {
            R.id.item1 -> {
                showToast(context, "Item 1")
                true
            }

            R.id.item2 -> {
                showToast(context, "Item 2")
                true
            }

            R.id.item3 -> {
                showToast(context, "Item 3")
                true
            }

            else -> false
        }
    }

    popupMenu.show()
}
