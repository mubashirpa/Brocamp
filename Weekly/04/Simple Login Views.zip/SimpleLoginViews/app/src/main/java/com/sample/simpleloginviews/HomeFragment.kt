package com.sample.simpleloginviews

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.sample.simpleloginviews.databinding.FragmentHomeBinding
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?,
    ) {
        super.onViewCreated(view, savedInstanceState)

        val array = Array(20) { it }
        val arrayAdapter = ArrayAdapter(requireContext(), R.layout.list_item, R.id.listId, array)
        binding.listView.adapter = arrayAdapter

        binding.extendedFab.setOnClickListener {
            lifecycleScope.launch {
                logout(requireContext()) {
                    findNavController().navigate(Login)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private suspend fun logout(
        context: Context,
        onSuccess: () -> Unit,
    ) {
        context.datastore.edit { settings ->
            settings[booleanPreferencesKey("login")] = false
        }
        onSuccess()
    }
}
