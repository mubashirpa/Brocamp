package com.sample.simpleloginviews

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.doOnTextChanged
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.sample.simpleloginviews.databinding.FragmentLoginBinding
import kotlinx.coroutines.launch

class LoginFragment : Fragment() {
    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?,
    ) {
        super.onViewCreated(view, savedInstanceState)

        binding.emailField.editText?.doOnTextChanged { _, _, _, _ ->
            binding.emailField.error = null
        }

        binding.passwordField.editText?.doOnTextChanged { _, _, _, _ ->
            binding.passwordField.error = null
        }

        binding.loginButton.setOnClickListener {
            val isEmailError =
                !validateEmail(
                    binding.emailField.editText
                        ?.text
                        .toString(),
                )
            val isPasswordError =
                !validatePassword(
                    binding.passwordField.editText
                        ?.text
                        .toString(),
                )

            if (isEmailError) {
                binding.emailField.error = "Please enter a valid email"
            }

            if (isPasswordError) {
                binding.passwordField.error = "Please enter a valid password"
            }

            if (!isEmailError && !isPasswordError) {
                lifecycleScope.launch {
                    login(requireContext()) {
                        findNavController().navigate(Home)
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun validateEmail(email: String): Boolean = email == "admin@gmail.com"

    private fun validatePassword(password: String): Boolean = password == "admin@123"

    private suspend fun login(
        context: Context,
        onSuccess: () -> Unit,
    ) {
        context.datastore.edit { settings ->
            settings[booleanPreferencesKey("login")] = true
        }
        onSuccess()
    }
}
