package com.sample.simpleloginviews

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.navigation.createGraph
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.fragment
import com.sample.simpleloginviews.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.Serializable

val Context.datastore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val isLoggedIn = isLoggedIn(this)

        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController

        navController.graph =
            navController.createGraph(
                startDestination = if (isLoggedIn == true) Home else Login,
            ) {
                fragment<LoginFragment, Login> {
                    label = "Login"
                }

                fragment<HomeFragment, Home> {
                    label = "Home"
                }
            }
    }

    private fun isLoggedIn(context: Context): Boolean? =
        runBlocking {
            context.datastore.data
                .map { preferences ->
                    preferences[booleanPreferencesKey("login")]
                }.first()
        }
}

@Serializable
object Login

@Serializable
object Home
