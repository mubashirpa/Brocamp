package com.sample.roomsample

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
data class Contact(
    val firstName: String,
    val lastName: String,
    @ColumnInfo(name = "phoneNumber")
    val phoneNumber: String,
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
)
