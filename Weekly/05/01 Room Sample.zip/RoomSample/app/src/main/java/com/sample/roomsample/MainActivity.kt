package com.sample.roomsample

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.sample.roomsample.presentation.contact.ContactScreen
import com.sample.roomsample.presentation.contact.ContactViewModel
import com.sample.roomsample.ui.theme.RoomSampleTheme

class MainActivity : ComponentActivity() {
    private val database by lazy {
        Room
            .databaseBuilder(
                applicationContext,
                ContactDatabase::class.java,
                "contacts.db",
            ).build()
    }
    private val viewModel by viewModels<ContactViewModel> {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T = ContactViewModel(database.contactDao()) as T
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RoomSampleTheme {
                val uiState by viewModel.state.collectAsState()

                ContactScreen(
                    uiState = uiState,
                    onEvent = viewModel::onEvent,
                )
            }
        }
    }
}
