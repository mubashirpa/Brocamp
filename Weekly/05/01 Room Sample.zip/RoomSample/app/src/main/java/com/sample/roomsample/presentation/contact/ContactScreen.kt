package com.sample.roomsample.presentation.contact

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ContactScreen(
    uiState: ContactUiState,
    onEvent: (ContactUiEvent) -> Unit,
) {
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    onEvent(ContactUiEvent.OnShowAddContactDialogChange(true))
                },
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add contact",
                )
            }
        },
    ) { innerPadding ->
        if (uiState.showAddContactDialog) {
            AddContactDialog(uiState = uiState, onEvent = onEvent)
        }

        LazyColumn(
            modifier = Modifier.padding(innerPadding),
            contentPadding = innerPadding,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Row(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    SortType.entries.forEach { sortType ->
                        Row(
                            modifier =
                                Modifier
                                    .clickable {
                                        onEvent(ContactUiEvent.OnSortContacts(sortType))
                                    },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(
                                selected = uiState.sortType == sortType,
                                onClick = {
                                    onEvent(ContactUiEvent.OnSortContacts(sortType))
                                },
                            )
                            Text(text = sortType.name)
                        }
                    }
                }
            }
            items(uiState.contacts) { contact ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(
                            text = "${contact.firstName} ${contact.lastName}",
                            fontSize = 20.sp,
                        )
                        Text(text = contact.phoneNumber, fontSize = 12.sp)
                    }
                    IconButton(onClick = {
                        onEvent(ContactUiEvent.OnDeleteContact(contact))
                    }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete contact",
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AddContactDialog(
    uiState: ContactUiState,
    onEvent: (ContactUiEvent) -> Unit,
    modifier: Modifier = Modifier,
) {
    AlertDialog(
        onDismissRequest = {
            onEvent(ContactUiEvent.OnShowAddContactDialogChange(false))
        },
        confirmButton = {
            Button(onClick = {
                onEvent(ContactUiEvent.OnSaveContact)
            }) {
                Text(text = "Save")
            }
        },
        modifier = modifier,
        title = {
            Text(text = "Add contact")
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextField(
                    value = uiState.firstName,
                    onValueChange = {
                        onEvent(ContactUiEvent.OnFirstNameValueChange(it))
                    },
                    placeholder = {
                        Text(text = "First name")
                    },
                )
                TextField(
                    value = uiState.lastName,
                    onValueChange = {
                        onEvent(ContactUiEvent.OnLastNameValueChange(it))
                    },
                    placeholder = {
                        Text(text = "Last name")
                    },
                )
                TextField(
                    value = uiState.phoneNumber,
                    onValueChange = {
                        onEvent(ContactUiEvent.OnPhoneNumberValueChange(it))
                    },
                    placeholder = {
                        Text(text = "Phone number")
                    },
                )
            }
        },
    )
}
