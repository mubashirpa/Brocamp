package com.sample.roomsample.presentation.contact

import com.sample.roomsample.Contact

sealed class ContactUiEvent {
    data class OnFirstNameValueChange(
        val firstName: String,
    ) : ContactUiEvent()

    data class OnLastNameValueChange(
        val lastName: String,
    ) : ContactUiEvent()

    data class OnPhoneNumberValueChange(
        val phoneNumber: String,
    ) : ContactUiEvent()

    data class OnShowAddContactDialogChange(
        val show: Boolean,
    ) : ContactUiEvent()

    data class OnSortContacts(
        val sortType: SortType,
    ) : ContactUiEvent()

    data object OnSaveContact : ContactUiEvent()

    data class OnDeleteContact(
        val contact: Contact,
    ) : ContactUiEvent()
}
