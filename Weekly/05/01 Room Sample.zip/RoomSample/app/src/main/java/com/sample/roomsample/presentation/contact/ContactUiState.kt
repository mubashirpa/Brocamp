package com.sample.roomsample.presentation.contact

import com.sample.roomsample.Contact

data class ContactUiState(
    val contacts: List<Contact> = emptyList(),
    val firstName: String = "",
    val lastName: String = "",
    val phoneNumber: String = "",
    val showAddContactDialog: Boolean = false,
    val sortType: SortType = SortType.FIRST_NAME,
)
