package com.sample.roomsample.presentation.contact

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sample.roomsample.Contact
import com.sample.roomsample.ContactDao
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ContactViewModel(
    private val contactDao: ContactDao,
) : ViewModel() {
    private val _sortType = MutableStateFlow(SortType.FIRST_NAME)
    private val _contacts =
        _sortType
            .flatMapLatest { sortType ->
                when (sortType) {
                    SortType.FIRST_NAME -> contactDao.getContactsOrderedByFirstName()
                    SortType.LAST_NAME -> contactDao.getContactsOrderedByLastName()
                    SortType.PHONE_NUMBER -> contactDao.getContactsOrderedByPhoneNumber()
                }
            }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), emptyList())
    private val _state = MutableStateFlow(ContactUiState())
    val state =
        combine(_state, _sortType, _contacts) { state, sortType, contacts ->
            state.copy(
                contacts = contacts,
                sortType = sortType,
            )
        }.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(stopTimeoutMillis = 5000),
            ContactUiState(),
        )

    fun onEvent(event: ContactUiEvent) {
        when (event) {
            is ContactUiEvent.OnDeleteContact -> {
                viewModelScope.launch {
                    contactDao.deleteContact(event.contact)
                }
            }

            is ContactUiEvent.OnFirstNameValueChange -> {
                _state.update {
                    it.copy(
                        firstName = event.firstName,
                    )
                }
            }

            is ContactUiEvent.OnLastNameValueChange -> {
                _state.update {
                    it.copy(
                        lastName = event.lastName,
                    )
                }
            }

            is ContactUiEvent.OnPhoneNumberValueChange -> {
                _state.update {
                    it.copy(
                        phoneNumber = event.phoneNumber,
                    )
                }
            }

            ContactUiEvent.OnSaveContact -> {
                val firstName = state.value.firstName
                val lastName = state.value.lastName
                val phoneNumber = state.value.phoneNumber

                if (firstName.isBlank() || lastName.isBlank() || phoneNumber.isBlank()) {
                    return
                }

                val contact =
                    Contact(
                        firstName = firstName,
                        lastName = lastName,
                        phoneNumber = phoneNumber,
                    )

                viewModelScope.launch {
                    contactDao.upsertContact(contact)
                }

                _state.update {
                    it.copy(
                        showAddContactDialog = false,
                        firstName = "",
                        lastName = "",
                        phoneNumber = "",
                    )
                }
            }

            is ContactUiEvent.OnShowAddContactDialogChange -> {
                _state.update {
                    it.copy(
                        showAddContactDialog = event.show,
                    )
                }
            }

            is ContactUiEvent.OnSortContacts -> {
                _sortType.value = event.sortType
            }
        }
    }
}
