package com.sample.roomsample.presentation.contact

enum class SortType {
    FIRST_NAME,
    LAST_NAME,
    PHONE_NUMBER,
}
