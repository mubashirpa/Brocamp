package com.sample.storagesample

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.sample.storagesample.ui.theme.StorageSampleTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val applicationContext = applicationContext

        enableEdgeToEdge()
        setContent {
            StorageSampleTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    val context = LocalContext.current
                    val coroutineScope = rememberCoroutineScope()
                    var images by remember { mutableStateOf(emptyList<Uri>()) }
                    val pickMedia =
                        rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
                            images = listOfNotNull(uri)
                        }

                    val takePicture =
                        rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
                            bitmap?.let {
                                coroutineScope.launch {
                                    saveImage(
                                        applicationContext,
                                        UUID.randomUUID().toString(),
                                        bitmap,
                                    )
                                }
                            }
                        }

                    val createDocument =
                        rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
                            uri?.let {
                                contentResolver.openOutputStream(uri)?.use { outputStream ->
                                    outputStream.write("Hello World".toByteArray())
                                }
                            }
                        }

                    val openDocument =
                        rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                            uri?.let {
                                contentResolver.openInputStream(uri)?.use { inputStream ->
                                    val text = inputStream.bufferedReader().readText()
                                    Log.i("OpenDocument", text)
                                }
                            }
                        }

                    val permissionLauncher =
                        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
                            if (isGranted) {
                                Log.i("Permission", "Granted")
                            } else {
                                Log.i("Permission", "Denied")
                            }
                        }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = innerPadding,
                    ) {
                        item {
                            Row(
                                modifier =
                                    Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState())
                                        .padding(horizontal = 10.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Button(onClick = {
                                    if (ContextCompat.checkSelfPermission(
                                            context,
                                            android.Manifest.permission.READ_EXTERNAL_STORAGE,
                                        ) == PackageManager.PERMISSION_DENIED
                                    ) {
                                        permissionLauncher.launch(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                                    }
                                }) {
                                    Text(text = "Get Permission")
                                }
                                Button(onClick = {
                                    coroutineScope.launch {
                                        images = getImages(applicationContext)
                                    }
                                }) {
                                    Text(text = "Get Images")
                                }
                                Button(onClick = {
                                    pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                }) {
                                    Text(text = "Pick Image")
                                }
                                Button(onClick = {
                                    takePicture.launch()
                                }) {
                                    Text(text = "Capture Image")
                                }
                                Button(onClick = {
                                    createDocument.launch("test.pdf")
                                }) {
                                    Text(text = "Create Pdf")
                                }
                                Button(onClick = {
                                    openDocument.launch(arrayOf("application/pdf"))
                                }) {
                                    Text(text = "Open Pdf")
                                }
                            }
                        }
                        items(items = images, key = { it.toString() }) {
                            AsyncImage(
                                model = it,
                                contentDescription = null,
                            )
                        }
                    }
                }
            }
        }
    }
}

suspend fun getImages(applicationContext: Context): List<Uri> {
    val list = mutableListOf<Uri>()

    return withContext(Dispatchers.IO) {
        applicationContext.contentResolver
            .query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                null,
                null,
                null,
                null,
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val contentUri: Uri =
                        ContentUris.withAppendedId(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            id,
                        )
                    list.add(contentUri)
                }

                cursor.close()
            }
        list
    }
}

suspend fun saveImage(
    applicationContext: Context,
    displayName: String,
    bitmap: Bitmap,
): Boolean {
    return withContext(Dispatchers.IO) {
        val imageCollection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val contentValues =
            ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "$displayName.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.WIDTH, bitmap.width)
                put(MediaStore.Images.Media.HEIGHT, bitmap.height)
            }
        val contentResolver = applicationContext.contentResolver

        return@withContext try {
            contentResolver.insert(imageCollection, contentValues)?.also { uri ->
                contentResolver.openOutputStream(uri)?.use { outputStream ->
                    if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 95, outputStream)) {
                        throw IOException("Couldn't save bitmap")
                    }
                } ?: throw IOException("Couldn't create MediaStore entry")
            } ?: throw IOException("Couldn't create MediaStore entry")
            true
        } catch (e: IOException) {
            e.printStackTrace()
            false
        }
    }
}
