package com.sample.studentrecord

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sample.studentrecord.presentation.studentDetails.StudentDetailsScreen
import com.sample.studentrecord.presentation.studentDetails.StudentDetailsViewModel
import com.sample.studentrecord.presentation.students.StudentsScreen
import com.sample.studentrecord.presentation.students.StudentsViewModel
import com.sample.studentrecord.ui.theme.StudentRecordTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.serialization.Serializable

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StudentRecordTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets(0),
                ) { innerPadding ->
                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        startDestination = Students,
                        modifier =
                            Modifier
                                .fillMaxSize()
                                .padding(innerPadding),
                    ) {
                        composable<Students> {
                            val viewModel: StudentsViewModel = hiltViewModel()
                            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                            StudentsScreen(
                                uiState = uiState,
                                onEvent = viewModel::onEvent,
                                navigateToStudentDetails = {
                                    navController.navigate(StudentDetails(it))
                                },
                            )
                        }
                        composable<StudentDetails> {
                            val viewModel: StudentDetailsViewModel = hiltViewModel()
                            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                            StudentDetailsScreen(uiState = uiState) {
                                navController.navigateUp()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Serializable
data object Students

@Serializable
data class StudentDetails(
    val studentId: Int,
)
