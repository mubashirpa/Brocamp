package com.sample.studentrecord

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class StudentRecordApplication : Application()
