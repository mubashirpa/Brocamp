package com.sample.studentrecord.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Query
import androidx.room.Upsert
import com.sample.studentrecord.data.local.entity.Student
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY name ASC")
    fun getAllStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE studentId LIKE :id LIMIT 1")
    fun getStudentById(id: Int): Flow<Student>

    @Query("SELECT * FROM students WHERE name LIKE '%' || :name || '%'")
    fun findStudentsByName(name: String): Flow<List<Student>>

    @Upsert
    suspend fun upsertStudent(student: Student)

    @Upsert
    suspend fun upsertStudents(students: List<Student>)

    @Delete
    suspend fun deleteStudent(student: Student)
}
