package com.sample.studentrecord.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.sample.studentrecord.data.local.dao.StudentDao
import com.sample.studentrecord.data.local.entity.Student

@Database(
    entities = [Student::class],
    version = 1,
)
abstract class StudentDatabase : RoomDatabase() {
    abstract fun studentDao(): StudentDao
}
