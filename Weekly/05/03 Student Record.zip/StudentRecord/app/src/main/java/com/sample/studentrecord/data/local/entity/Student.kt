package com.sample.studentrecord.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    val name: String,
    val age: Int,
    val phone: String,
    val place: String,
    val image: ByteArray?,
    @PrimaryKey(autoGenerate = true)
    val studentId: Int = 0,
)
