package com.sample.studentrecord.di

import android.app.Application
import androidx.room.Room
import com.sample.studentrecord.data.local.database.StudentDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Singleton
    @Provides
    fun provideDatabase(app: Application): StudentDatabase = Room.databaseBuilder(app, StudentDatabase::class.java, "student_db").build()

    @Singleton
    @Provides
    fun provideStudentDao(db: StudentDatabase) = db.studentDao()
}
