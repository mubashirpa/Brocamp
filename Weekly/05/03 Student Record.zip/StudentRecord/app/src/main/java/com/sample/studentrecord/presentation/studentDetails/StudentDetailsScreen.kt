package com.sample.studentrecord.presentation.studentDetails

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentDetailsScreen(
    uiState: StudentDetailsUiState,
    onBackPressed: () -> Unit = {},
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Text(text = "Student Details")
            },
            navigationIcon = {
                IconButton(onClick = onBackPressed) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = null,
                    )
                }
            },
        )
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier =
                    Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                uiState.student?.image?.let { imageBytes ->
                    val bitmap =
                        remember(imageBytes) {
                            BitmapFactory
                                .decodeByteArray(imageBytes, 0, imageBytes.size)
                                .asImageBitmap()
                        }
                    Image(
                        bitmap = bitmap,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )
                } ?: Text(
                    text =
                        uiState.student
                            ?.name
                            .toString()
                            .first()
                            .uppercase(),
                    color = MaterialTheme.colorScheme.onPrimary,
                    style = MaterialTheme.typography.displaySmall,
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            ListItem(
                headlineContent = {
                    Text(text = uiState.student?.name.toString())
                },
                overlineContent = {
                    Text(text = "Name")
                },
                leadingContent = {
                    Icon(imageVector = Icons.Default.Person, contentDescription = null)
                },
            )
            HorizontalDivider(modifier = Modifier.padding(start = 56.dp))
            ListItem(
                headlineContent = {
                    Text(text = uiState.student?.age.toString())
                },
                overlineContent = {
                    Text(text = "Age")
                },
                leadingContent = {
                    Icon(imageVector = Icons.Default.Info, contentDescription = null)
                },
            )
            HorizontalDivider(modifier = Modifier.padding(start = 56.dp))
            ListItem(
                headlineContent = {
                    Text(text = uiState.student?.phone.toString())
                },
                overlineContent = {
                    Text(text = "Phone")
                },
                leadingContent = {
                    Icon(imageVector = Icons.Default.Phone, contentDescription = null)
                },
            )
            HorizontalDivider(modifier = Modifier.padding(start = 56.dp))
            ListItem(
                headlineContent = {
                    Text(text = uiState.student?.place.toString())
                },
                overlineContent = {
                    Text(text = "Place")
                },
                leadingContent = {
                    Icon(imageVector = Icons.Default.Place, contentDescription = null)
                },
            )
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
