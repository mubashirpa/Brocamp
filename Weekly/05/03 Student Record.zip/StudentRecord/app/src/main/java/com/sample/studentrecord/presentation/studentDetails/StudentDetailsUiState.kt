package com.sample.studentrecord.presentation.studentDetails

import com.sample.studentrecord.data.local.entity.Student

data class StudentDetailsUiState(
    val student: Student? = null,
)
