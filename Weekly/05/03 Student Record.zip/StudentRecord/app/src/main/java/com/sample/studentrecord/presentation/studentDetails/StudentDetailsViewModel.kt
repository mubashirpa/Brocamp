package com.sample.studentrecord.presentation.studentDetails

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.sample.studentrecord.StudentDetails
import com.sample.studentrecord.data.local.dao.StudentDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class StudentDetailsViewModel
    @Inject
    constructor(
        private val studentDao: StudentDao,
        savedStateHandle: SavedStateHandle,
    ) : ViewModel() {
        private val _uiState = MutableStateFlow(StudentDetailsUiState())
        val uiState: StateFlow<StudentDetailsUiState> = _uiState

        private val studentId: Int = savedStateHandle.toRoute<StudentDetails>().studentId

        init {
            viewModelScope.launch {
                studentDao
                    .getStudentById(studentId)
                    .distinctUntilChanged()
                    .collect { student ->
                        _uiState.update { currentState ->
                            currentState.copy(student = student)
                        }
                    }
            }
        }
    }
