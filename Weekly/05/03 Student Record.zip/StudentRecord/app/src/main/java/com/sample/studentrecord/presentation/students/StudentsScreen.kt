package com.sample.studentrecord.presentation.students

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SearchBar
import androidx.compose.material3.SearchBarDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.isTraversalGroup
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.traversalIndex
import androidx.compose.ui.unit.dp
import com.sample.studentrecord.presentation.students.components.AddStudentDialog
import com.sample.studentrecord.presentation.students.components.StudentListItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentsScreen(
    uiState: StudentsUiState,
    onEvent: (StudentsUiEvent) -> Unit,
    navigateToStudentDetails: (Int) -> Unit,
) {
    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                text = {
                    Text(text = "Add student")
                },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                    )
                },
                onClick = {
                    onEvent(StudentsUiEvent.OnOpenAddStudentDialogChange(true))
                },
            )
        },
    ) { innerPadding ->
        Box(
            Modifier
                .fillMaxSize()
                .semantics { isTraversalGroup = true },
        ) {
            SearchBar(
                modifier =
                    Modifier
                        .align(Alignment.TopCenter)
                        .semantics { traversalIndex = 0f },
                inputField = {
                    SearchBarDefaults.InputField(
                        query = uiState.searchQuery,
                        onQueryChange = {
                            onEvent(StudentsUiEvent.OnSearchQueryChange(it))
                        },
                        onSearch = {
                            onEvent(StudentsUiEvent.OnSearch(it))
                        },
                        expanded = uiState.searchBarExpanded,
                        onExpandedChange = {
                            onEvent(StudentsUiEvent.OnSearchBarExpandedChange(it))
                        },
                        placeholder = {
                            Text(text = "Search")
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                            )
                        },
                    )
                },
                expanded = uiState.searchBarExpanded,
                onExpandedChange = {
                    onEvent(StudentsUiEvent.OnSearchBarExpandedChange(it))
                },
            ) {
                LazyColumn {
                    items(
                        items = uiState.searchResults,
                        key = { it.studentId },
                    ) {
                        StudentListItem(
                            name = it.name,
                            image = it.image,
                            onEditClick = {
                                onEvent(
                                    StudentsUiEvent.OnOpenAddStudentDialogChange(
                                        open = true,
                                        student = it,
                                    ),
                                )
                            },
                            onDeleteClick = {
                                onEvent(StudentsUiEvent.DeleteStudent(it))
                            },
                            onClick = {
                                onEvent(StudentsUiEvent.OnSearchBarExpandedChange(false))
                                navigateToStudentDetails(it.studentId)
                            },
                        )
                    }
                }
            }

            LazyColumn(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .semantics { traversalIndex = 1f },
                contentPadding = PaddingValues(top = 72.dp),
            ) {
                items(
                    items = uiState.students,
                    key = { it.studentId },
                ) {
                    StudentListItem(
                        name = it.name,
                        image = it.image,
                        onEditClick = {
                            onEvent(
                                StudentsUiEvent.OnOpenAddStudentDialogChange(
                                    open = true,
                                    student = it,
                                ),
                            )
                        },
                        onDeleteClick = {
                            onEvent(StudentsUiEvent.DeleteStudent(it))
                        },
                        onClick = {
                            navigateToStudentDetails(it.studentId)
                        },
                    )
                }
            }
        }
    }

    AddStudentDialog(
        onDismissRequest = {
            onEvent(StudentsUiEvent.OnOpenAddStudentDialogChange(false))
        },
        openDialog = uiState.openAddStudentDialog,
        student = uiState.studentEdit,
        onConfirmClick = {
            onEvent(StudentsUiEvent.AddStudent(it))
        },
    )
}
