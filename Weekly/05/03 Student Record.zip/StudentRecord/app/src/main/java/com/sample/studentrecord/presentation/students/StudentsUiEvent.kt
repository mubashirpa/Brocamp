package com.sample.studentrecord.presentation.students

import com.sample.studentrecord.data.local.entity.Student

sealed class StudentsUiEvent {
    data class OnOpenAddStudentDialogChange(
        val open: Boolean,
        val student: Student? = null,
    ) : StudentsUiEvent()

    data class AddStudent(
        val student: Student,
    ) : StudentsUiEvent()

    data class DeleteStudent(
        val student: Student,
    ) : StudentsUiEvent()

    data class OnSearchQueryChange(
        val query: String,
    ) : StudentsUiEvent()

    data class OnSearchBarExpandedChange(
        val expanded: Boolean,
    ) : StudentsUiEvent()

    data class OnSearch(
        val query: String,
    ) : StudentsUiEvent()
}
