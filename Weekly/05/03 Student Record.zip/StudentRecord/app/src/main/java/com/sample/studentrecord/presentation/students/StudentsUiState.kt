package com.sample.studentrecord.presentation.students

import com.sample.studentrecord.data.local.entity.Student

data class StudentsUiState(
    val students: List<Student> = emptyList(),
    val openAddStudentDialog: Boolean = false,
    val studentEdit: Student? = null,
    val searchQuery: String = "",
    val searchBarExpanded: Boolean = false,
    val searchResults: List<Student> = emptyList(),
)
