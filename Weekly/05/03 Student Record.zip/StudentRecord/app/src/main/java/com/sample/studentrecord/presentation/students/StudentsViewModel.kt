package com.sample.studentrecord.presentation.students

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sample.studentrecord.data.local.dao.StudentDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class StudentsViewModel
    @Inject
    constructor(
        private val studentDao: StudentDao,
    ) : ViewModel() {
        private val _uiState = MutableStateFlow(StudentsUiState())
        val uiState: StateFlow<StudentsUiState> = _uiState.asStateFlow()

        init {
            viewModelScope.launch {
                studentDao
                    .getAllStudents()
                    .distinctUntilChanged()
                    .collect { students ->
                        _uiState.update { currentState ->
                            currentState.copy(students = students)
                        }
                    }
            }
        }

        fun onEvent(event: StudentsUiEvent) {
            when (event) {
                is StudentsUiEvent.OnOpenAddStudentDialogChange -> {
                    _uiState.update { currentState ->
                        currentState.copy(
                            openAddStudentDialog = event.open,
                            studentEdit = event.student,
                        )
                    }
                }

                is StudentsUiEvent.AddStudent -> {
                    viewModelScope.launch {
                        studentDao.upsertStudent(event.student)
                    }
                }

                is StudentsUiEvent.DeleteStudent -> {
                    viewModelScope.launch {
                        studentDao.deleteStudent(event.student)
                    }
                }

                is StudentsUiEvent.OnSearchQueryChange -> {
                    _uiState.update { currentState ->
                        currentState.copy(
                            searchQuery = event.query,
                            searchResults = emptyList(),
                        )
                    }
                }

                is StudentsUiEvent.OnSearch -> {
                    viewModelScope.launch {
                        studentDao
                            .findStudentsByName(event.query)
                            .distinctUntilChanged()
                            .collect { students ->
                                _uiState.update { currentState ->
                                    currentState.copy(searchResults = students)
                                }
                            }
                    }
                }

                is StudentsUiEvent.OnSearchBarExpandedChange -> {
                    _uiState.update { currentState ->
                        currentState.copy(
                            searchQuery = "",
                            searchBarExpanded = event.expanded,
                            searchResults = emptyList(),
                        )
                    }
                }
            }
        }
    }
