package com.sample.studentrecord.presentation.students.components

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.sample.studentrecord.data.local.entity.Student
import com.sample.studentrecord.ui.theme.StudentRecordTheme
import kotlinx.coroutines.launch

@Composable
fun AddStudentDialog(
    onDismissRequest: () -> Unit,
    openDialog: Boolean,
    student: Student? = null,
    onConfirmClick: (Student) -> Unit,
) {
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("") }
    var age by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var place by rememberSaveable { mutableStateOf("") }
    var isNameError by remember { mutableStateOf(false) }
    var isAgeError by remember { mutableStateOf(false) }
    var isPhoneError by remember { mutableStateOf(false) }
    var isPlaceError by remember { mutableStateOf(false) }
    var imageBytes by remember { mutableStateOf<ByteArray?>(null) }
    val photoPicker =
        rememberLauncherForActivityResult(contract = ActivityResultContracts.PickVisualMedia()) { uri ->
            uri?.let {
                context.contentResolver.openInputStream(it)?.use { inputStream ->
                    imageBytes = inputStream.readBytes()
                }
            }
        }

    LaunchedEffect(student) {
        if (student != null) {
            name = student.name
            age = student.age.toString()
            phone = student.phone
            place = student.place
            imageBytes = student.image
        }
    }

    if (openDialog) {
        Dialog(onDismissRequest = {
            // Reset values when dialog is dismissed
            name = ""
            age = ""
            phone = ""
            place = ""
            imageBytes = null
            // Reset error states when dialog is dismissed
            isNameError = false
            isAgeError = false
            isPhoneError = false
            isPlaceError = false
            onDismissRequest()
        }) {
            Surface(
                modifier =
                    Modifier
                        .wrapContentWidth()
                        .wrapContentHeight(),
                shape = AlertDialogDefaults.shape,
                color = AlertDialogDefaults.containerColor,
                tonalElevation = AlertDialogDefaults.TonalElevation,
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = "Add Student",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.headlineSmall,
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier =
                            Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondaryContainer)
                                .clickable {
                                    photoPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                                    )
                                },
                        contentAlignment = Alignment.Center,
                    ) {
                        imageBytes?.let { byteArray ->
                            val bitmap =
                                remember(imageBytes) {
                                    BitmapFactory
                                        .decodeByteArray(byteArray, 0, byteArray.size)
                                        .asImageBitmap()
                                }

                            Image(
                                bitmap = bitmap,
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop,
                            )
                        } ?: Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Add photo",
                            modifier = Modifier.size(36.dp),
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    TextField(
                        value = name,
                        onValueChange = {
                            isNameError = false
                            name = it
                        },
                        label = {
                            Text("Name")
                        },
                        supportingText =
                            if (isNameError) {
                                {
                                    Text(text = "Please enter a valid name")
                                }
                            } else {
                                null
                            },
                        isError = isNameError,
                        keyboardOptions =
                            KeyboardOptions(
                                capitalization = KeyboardCapitalization.Words,
                                keyboardType = KeyboardType.Text,
                            ),
                        singleLine = true,
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    TextField(
                        value = age,
                        onValueChange = {
                            isAgeError = false
                            age = it
                        },
                        label = {
                            Text("Age")
                        },
                        supportingText =
                            if (isAgeError) {
                                {
                                    Text(text = "Please enter a valid age")
                                }
                            } else {
                                null
                            },
                        isError = isAgeError,
                        keyboardOptions =
                            KeyboardOptions(
                                capitalization = KeyboardCapitalization.Words,
                                keyboardType = KeyboardType.Number,
                            ),
                        singleLine = true,
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    TextField(
                        value = phone,
                        onValueChange = {
                            isPhoneError = false
                            phone = it
                        },
                        label = {
                            Text("Phone")
                        },
                        supportingText =
                            if (isPhoneError) {
                                {
                                    Text(text = "Please enter a valid phone number")
                                }
                            } else {
                                null
                            },
                        isError = isPhoneError,
                        keyboardOptions =
                            KeyboardOptions(
                                capitalization = KeyboardCapitalization.Words,
                                keyboardType = KeyboardType.Phone,
                            ),
                        singleLine = true,
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    TextField(
                        value = place,
                        onValueChange = {
                            isPlaceError = false
                            place = it
                        },
                        label = {
                            Text("Place")
                        },
                        supportingText =
                            if (isPlaceError) {
                                {
                                    Text(text = "Please enter a valid place")
                                }
                            } else {
                                null
                            },
                        isError = isPlaceError,
                        keyboardOptions =
                            KeyboardOptions(
                                capitalization = KeyboardCapitalization.Words,
                                keyboardType = KeyboardType.Text,
                            ),
                        singleLine = true,
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.align(Alignment.End)) {
                        TextButton(onClick = {
                            // Reset values when dialog is dismissed
                            name = ""
                            age = ""
                            phone = ""
                            place = ""
                            // Reset error states when dialog is dismissed
                            isNameError = false
                            isAgeError = false
                            isPhoneError = false
                            isPlaceError = false
                            onDismissRequest()
                        }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(onClick = {
                            val formattedAge =
                                try {
                                    age.toInt()
                                } catch (e: NumberFormatException) {
                                    0
                                }

                            if (name.isBlank()) {
                                isNameError = true
                            }
                            if (formattedAge <= 0 || formattedAge > 100) {
                                isAgeError = true
                            }
                            if (phone.isBlank()) {
                                isPhoneError = true
                            }
                            if (place.isBlank()) {
                                isPlaceError = true
                            }

                            val error =
                                listOf(
                                    isNameError,
                                    isAgeError,
                                    isPhoneError,
                                    isPlaceError,
                                ).any { it }

                            if (!error) {
                                onDismissRequest()
                                onConfirmClick(
                                    student?.copy(
                                        name = name,
                                        age = formattedAge,
                                        phone = phone,
                                        place = place,
                                        image = imageBytes,
                                    ) ?: Student(
                                        name = name,
                                        age = formattedAge,
                                        phone = phone,
                                        place = place,
                                        image = imageBytes,
                                    ),
                                )
                                // Reset values after adding student
                                name = ""
                                age = ""
                                phone = ""
                                place = ""
                                imageBytes = null
                            }
                        }) {
                            Text("Add")
                        }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun AddStudentDialogPreview() {
    StudentRecordTheme {
        AddStudentDialog(
            onDismissRequest = {},
            openDialog = true,
            onConfirmClick = {},
        )
    }
}
