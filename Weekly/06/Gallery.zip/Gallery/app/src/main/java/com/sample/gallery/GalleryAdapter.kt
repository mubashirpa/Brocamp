package com.sample.gallery

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sample.gallery.databinding.GalleryListItemBinding

class GalleryAdapter(
    private var list: List<GalleryItem>,
    private val onClickListener: OnItemClickListener? = null,
) : RecyclerView.Adapter<GalleryAdapter.ViewHolder>() {
    class ViewHolder(
        val binding: GalleryListItemBinding,
    ) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): ViewHolder {
        val binding =
            GalleryListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int,
    ) {
        holder.binding.apply {
            image.setImageBitmap(list[position].bitmap)

            image.setOnClickListener {
                onClickListener?.onItemClick(holder.adapterPosition)
            }

            image.setOnLongClickListener {
                onClickListener?.onItemLongClick(position)
                true
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun notifyDataChanged(newList: List<GalleryItem>) {
        list = newList
        notifyDataSetChanged()
    }
}

interface OnItemClickListener {
    fun onItemClick(position: Int)

    fun onItemLongClick(position: Int)
}
