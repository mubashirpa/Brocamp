package com.sample.gallery

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.sample.gallery.databinding.ActivityImageViewerBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class ImageViewerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityImageViewerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityImageViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val fileName = intent.getStringExtra("fileName")

        lifecycleScope.launch {
            val bitmap = openImage(fileName)
            bitmap?.let {
                binding.image.setImageBitmap(it)
            } ?: run {
                Toast
                    .makeText(this@ImageViewerActivity, "Failed to open image", Toast.LENGTH_SHORT)
                    .show()
                finish()
            }
        }

        binding.deleteButton.setOnClickListener {
            if (deleteFile(fileName)) {
                val resultIntent =
                    Intent().apply {
                        putExtra("file_deleted", true)
                    }
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            } else {
                Toast.makeText(this, "Failed to delete image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun openImage(fileName: String?): Bitmap? =
        withContext(Dispatchers.IO) {
            try {
                openFileInput(fileName)?.use {
                    BitmapFactory.decodeStream(it)
                } ?: throw IOException("Failed to open image")
            } catch (e: IOException) {
                e.printStackTrace()
                null
            }
        }
}
