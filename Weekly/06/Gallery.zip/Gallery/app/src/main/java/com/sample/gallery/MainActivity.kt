package com.sample.gallery

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.DisplayMetrics
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.sample.gallery.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var imageViewer: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        imageViewer =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    val isFileDeleted = result.data?.getBooleanExtra("file_deleted", false)
                    if (isFileDeleted == true) {
                        lifecycleScope.launch {
                            binding.recyclerView.adapter = initAdapter(loadImages())
                        }
                    }
                }
            }

        val captureImage =
            registerForActivityResult(ActivityResultContracts.TakePicturePreview()) {
                it?.let { bitmap ->
                    lifecycleScope.launch {
                        if (saveImage(bitmap)) {
                            Toast
                                .makeText(this@MainActivity, "Image saved", Toast.LENGTH_SHORT)
                                .show()

                            lifecycleScope.launch {
                                binding.recyclerView.adapter = initAdapter(loadImages())
                            }
                        } else {
                            Toast
                                .makeText(
                                    this@MainActivity,
                                    "Failed to save image",
                                    Toast.LENGTH_SHORT,
                                ).show()
                        }
                    }
                }
            }

        lifecycleScope.launch {
            val images = loadImages()
            binding.recyclerView.apply {
                layoutManager =
                    GridLayoutManager(
                        this@MainActivity,
                        SpanCount.adaptive(this@MainActivity, 100),
                    )
                adapter = initAdapter(images)
                addItemDecoration(
                    AdaptiveSpacingItemDecoration(
                        size = 4.toDp(),
                        edgeEnabled = true,
                    ),
                )
            }
        }

        binding.captureImage.setOnClickListener {
            captureImage.launch()
        }
    }

    private suspend fun saveImage(bitmap: Bitmap): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val filename = "${UUID.randomUUID()}.png"
                openFileOutput(filename, Context.MODE_PRIVATE)?.use { outputStream ->
                    if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)) {
                        throw IOException("Failed to save image")
                    }
                } ?: throw IOException("Failed to save image")
                true
            } catch (e: IOException) {
                e.printStackTrace()
                false
            }
        }

    private suspend fun loadImages(): List<GalleryItem> =
        withContext(Dispatchers.IO) {
            filesDir
                .listFiles()
                ?.filter { it.isFile && it.canRead() && it.name.endsWith(".png") }
                ?.mapNotNull { file ->
                    val bytes = file.readBytes()
                    GalleryItem(
                        fileName = file.name,
                        bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size),
                    )
                } ?: emptyList()
        }

    private fun initAdapter(images: List<GalleryItem>): GalleryAdapter =
        GalleryAdapter(
            list = images,
            onClickListener =
                object : OnItemClickListener {
                    override fun onItemClick(position: Int) {
                        Intent(this@MainActivity, ImageViewerActivity::class.java).apply {
                            putExtra("fileName", images[position].fileName)
                            imageViewer.launch(this)
                        }
                    }

                    override fun onItemLongClick(position: Int) {
                        val fileName = images[position].fileName
                        if (deleteFile(fileName)) {
                            Toast
                                .makeText(
                                    this@MainActivity,
                                    "Deleted $fileName",
                                    Toast.LENGTH_SHORT,
                                ).show()
                            lifecycleScope.launch {
                                binding.recyclerView.adapter = initAdapter(loadImages())
                            }
                        }
                    }
                },
        )
}

object SpanCount {
    fun adaptive(
        context: Context,
        minSize: Int,
    ): Int {
        val displayMetrics: DisplayMetrics = context.resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels.toFloat()

        var spanCount = (screenWidth / minSize.toDp(displayMetrics)).toInt()

        // Ensure there's at least 1 column
        if (spanCount < 1) spanCount = 1

        return spanCount
    }

    private fun Int.toDp(displayMetrics: DisplayMetrics): Int {
        val density = displayMetrics.density
        return ((this * density) + 0.5f).toInt()
    }
}

data class GalleryItem(
    val fileName: String,
    val bitmap: Bitmap,
)
