package com.sample.uidesigns

import androidx.fragment.app.Fragment

class DesignFiveFragment : Fragment(R.layout.design_five)
