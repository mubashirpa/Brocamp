package com.sample.uidesigns

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import com.sample.uidesigns.databinding.DesignFourBinding

class DesignFourFragment : Fragment() {
    private var _binding: DesignFourBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = DesignFourBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?,
    ) {
        super.onViewCreated(view, savedInstanceState)

        binding.faqItem1.setOnClickListener {
            binding.faqDescription1.isVisible = !binding.faqDescription1.isVisible
            val drawableId =
                if (binding.faqDescription1.isVisible) {
                    R.drawable.baseline_remove_24
                } else {
                    R.drawable.baseline_add_24
                }
            binding.faqTitle1.setCompoundDrawablesWithIntrinsicBounds(0, 0, drawableId, 0)
        }

        val assetLoader =
            WebViewAssetLoader
                .Builder()
                .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(requireContext()))
                .addPathHandler("/res/", WebViewAssetLoader.ResourcesPathHandler(requireContext()))
                .build()

        binding.webview.apply {
            settings.javaScriptEnabled = true
            webViewClient = LocalContentWebViewClient(assetLoader)
            loadUrl("https://appassets.androidplatform.net/assets/youtube.html")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

private class LocalContentWebViewClient(
    private val assetLoader: WebViewAssetLoader,
) : WebViewClientCompat() {
    override fun shouldInterceptRequest(
        view: WebView,
        request: WebResourceRequest,
    ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
}
