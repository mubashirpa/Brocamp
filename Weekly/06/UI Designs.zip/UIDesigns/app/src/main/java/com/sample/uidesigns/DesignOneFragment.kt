package com.sample.uidesigns

import androidx.fragment.app.Fragment

class DesignOneFragment : Fragment(R.layout.design_one)
