package com.sample.uidesigns

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.sample.uidesigns.databinding.DesignSixBinding
import com.sample.uidesigns.databinding.ListItemSixBinding

class DesignSixFragment : Fragment() {
    private var _binding: DesignSixBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = DesignSixBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?,
    ) {
        super.onViewCreated(view, savedInstanceState)

        val items =
            listOf(
                DesignSixItem(
                    image = R.drawable.img_tshirt,
                    title = "Couch Potato | Women | Blue",
                    price = 799,
                ),
                DesignSixItem(
                    image = R.drawable.img_shirt,
                    title = "Couch Potato | Men | Black",
                    price = 799,
                ),
                DesignSixItem(
                    image = R.drawable.img_mug,
                    title = "Mug | Explore",
                    price = 399,
                ),
                DesignSixItem(
                    image = R.drawable.img_tshirt,
                    title = "Combo Blahst 1 | Pack",
                    price = 699,
                ),
                DesignSixItem(
                    image = R.drawable.img_mug,
                    title = "Mug | Orchard",
                    price = 449,
                ),
                DesignSixItem(
                    image = R.drawable.img_tshirt,
                    title = "Combo Blahst 2 | Explore",
                    price = 599,
                ),
                DesignSixItem(
                    image = R.drawable.img_shirt,
                    title = "I See Combo Pack",
                    price = 1299,
                ),
                DesignSixItem(
                    image = R.drawable.img_shirt,
                    title = "Kids Combo Blahst",
                    price = 1199,
                ),
            )
        val adapter = DesignSixAdapter(items)
        binding.gridView.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class DesignSixAdapter(
    private var list: List<DesignSixItem>,
) : RecyclerView.Adapter<DesignSixAdapter.ViewHolder>() {
    class ViewHolder(
        val binding: ListItemSixBinding,
    ) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): ViewHolder {
        val binding = ListItemSixBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int,
    ) {
        holder.binding.title.text = list[position].title
        holder.binding.image.setImageResource(list[position].image)
        holder.binding.count.text = "${list[position].count} piece"
        holder.binding.price.text = "₹${list[position].price}"
    }
}

data class DesignSixItem(
    @DrawableRes val image: Int,
    val title: String,
    val count: Int = 1,
    val price: Int,
    val isStock: Boolean = true,
)
