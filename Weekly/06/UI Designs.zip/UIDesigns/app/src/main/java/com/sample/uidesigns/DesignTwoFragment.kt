package com.sample.uidesigns

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.sample.uidesigns.databinding.DesignTwoBinding
import com.sample.uidesigns.databinding.ListItemTwoBinding

class DesignTwoFragment : Fragment() {
    private var _binding: DesignTwoBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = DesignTwoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?,
    ) {
        super.onViewCreated(view, savedInstanceState)

        val items =
            listOf(
                ItemTwo(R.drawable.marketing_designs, "Marketing\nDesigns"),
                ItemTwo(R.drawable.online_payments, "Online\nPayments"),
                ItemTwo(R.drawable.discount_coupons, "Discount\nCoupons"),
                ItemTwo(R.drawable.my_customers, "My\nCustomers"),
                ItemTwo(R.drawable.store_qr_code, "Store QR\nCode"),
                ItemTwo(R.drawable.extra_charges, "Extra \nCharges"),
                ItemTwo(R.drawable.order_form, "Order\nForm", isNew = true),
            )
        val adapter = MyAdapter(items)
        binding.gridView.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class MyAdapter(
    private var list: List<ItemTwo>,
) : RecyclerView.Adapter<MyAdapter.ViewHolder>() {
    class ViewHolder(
        val binding: ListItemTwoBinding,
    ) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): ViewHolder {
        val binding = ListItemTwoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int,
    ) {
        holder.binding.title.text = list[position].title
        holder.binding.image.setImageResource(list[position].image)
        holder.binding.chip.isVisible = list[position].isNew
    }
}

data class ItemTwo(
    @DrawableRes val image: Int,
    val title: String,
    val isNew: Boolean = false,
)
