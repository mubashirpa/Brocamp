package com.sample.uidesigns

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import androidx.fragment.app.replace
import com.sample.uidesigns.databinding.LayoutMainBinding

class MainFragment : Fragment() {
    private var _binding: LayoutMainBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = LayoutMainBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?,
    ) {
        super.onViewCreated(view, savedInstanceState)

        with(requireActivity()) {
            binding.one.setOnClickListener {
                supportFragmentManager.commit {
                    setReorderingAllowed(true)
                    replace<DesignOneFragment>(R.id.fragment_container_view)
                    addToBackStack("one")
                }
            }

            binding.two.setOnClickListener {
                supportFragmentManager.commit {
                    setReorderingAllowed(true)
                    replace<DesignTwoFragment>(R.id.fragment_container_view)
                    addToBackStack("two")
                }
            }

            binding.three.setOnClickListener {
                supportFragmentManager.commit {
                    setReorderingAllowed(true)
                    replace<DesignThreeFragment>(R.id.fragment_container_view)
                    addToBackStack("three")
                }
            }

            binding.four.setOnClickListener {
                supportFragmentManager.commit {
                    setReorderingAllowed(true)
                    replace<DesignFourFragment>(R.id.fragment_container_view)
                    addToBackStack("four")
                }
            }

            binding.five.setOnClickListener {
                supportFragmentManager.commit {
                    setReorderingAllowed(true)
                    replace<DesignFiveFragment>(R.id.fragment_container_view)
                    addToBackStack("five")
                }
            }

            binding.six.setOnClickListener {
                supportFragmentManager.commit {
                    setReorderingAllowed(true)
                    replace<DesignSixFragment>(R.id.fragment_container_view)
                    addToBackStack("six")
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
